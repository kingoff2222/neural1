Neural Network
==============

<a href="http://nxxcxx.github.io/Neural-Network/" target="_blank">Demo</a>
<br/>
Cinema4D + three.js
<br/>
![](https://raw.githubusercontent.com/nxxcxx/Neural-Network/gh-pages/screenshot.jpg)
